/* =========================================================
   LEYENDAS DE SANTA CRUZ — interacciones
   Sin librerías: Canvas 2D, CSS 3D, IntersectionObserver,
   Web Audio API y un pequeño jichi escondido.
   ========================================================= */

(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const pad = (n) => String(n).padStart(2, '0');
  const legends = Array.isArray(window.LEGENDS) ? window.LEGENDS : [];
  const heroContent = $('.hero__content');

  let modalOpen = false;

  /* ------------------------------------------------------------ PRELOADER */

  const preloader = $('#preloader');
  const loadBar = $('#loadBar');
  const loadPct = $('#loadPct');
  let progress = 0;
  let pageLoaded = document.readyState === 'complete';
  let booted = false;
  let loadTimer = null;

  window.addEventListener('load', () => { pageLoaded = true; }, { once: true });
  setTimeout(() => { pageLoaded = true; }, 2400);

  function finishBoot() {
    if (booted) return;
    booted = true;
    if (loadTimer) clearInterval(loadTimer);
    if (loadBar) loadBar.style.width = '100%';
    if (loadPct) loadPct.textContent = '100%';
    document.body.classList.add('is-ready');
    if (preloader) {
      preloader.classList.add('is-done');
      setTimeout(() => preloader.remove(), 1000);
    }
    requestAnimationFrame(() => {
      layoutCarousel();
      startAutoplay();
    });
    /* Al terminar la entrada, soltamos la animación para que el parallax
       del scroll pueda mover el bloque con estilos en línea. */
    setTimeout(() => document.body.classList.add('is-settled'), 1900);
  }

  if (preloader) {
    loadTimer = setInterval(() => {
      progress = Math.min(progress + (pageLoaded ? 10 : 3.2), pageLoaded ? 100 : 92);
      if (loadBar) loadBar.style.width = progress + '%';
      if (loadPct) loadPct.textContent = Math.round(progress) + '%';
      if (progress >= 100) {
        clearInterval(loadTimer);
        setTimeout(finishBoot, 360);
      }
    }, 84);

    setTimeout(() => {
      if (booted) return;
      progress = 100;
      if (loadBar) loadBar.style.width = '100%';
      if (loadPct) loadPct.textContent = '100%';
      finishBoot();
    }, 4300);
  } else {
    finishBoot();
  }

  /* --------------------------------------------------------------- CARRUSEL */

  const stage = $('#stage');
  const carousel = $('#carousel');
  const dotsEl = $('#dots');
  const counterEl = $('#counter');
  const prevBtn = $('#prevBtn');
  const nextBtn = $('#nextBtn');

  let cards = [];
  let index = 0;
  let cardWidth = 300;
  let autoplayId = null;
  let autoPaused = false;
  let carouselVisible = true;
  let dragStart = null;
  let didDrag = false;
  let dragResetTimer = null;

  function cardTemplate(l, i) {
    return `
      <article class="legend-card" data-index="${i}" style="--a1-rgb:${l.a1rgb};--a2-rgb:${l.a2rgb}">
        <div class="card__inner">
          <span class="card__index" aria-hidden="true">${pad(i + 1)}</span>
          <figure class="card__art">
            <img src="${l.art}" alt="Ilustración 3D de ${l.name}" width="900" height="900"
              decoding="async" draggable="false" />
            <span class="card__art-fade" aria-hidden="true"></span>
          </figure>
          <div class="card__body">
            <p class="card__type">${l.type}</p>
            <h3 class="card__name">${l.name}</h3>
            <p class="card__teaser">${l.teaser}</p>
          </div>
          <div class="card__foot">
            <span class="card__region">${l.region}</span>
            <button class="card__btn" type="button" tabindex="-1" aria-label="Leer la leyenda ${l.name}">
              Leer
              <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg>
            </button>
          </div>
          <span class="card__shine" aria-hidden="true"></span>
        </div>
      </article>`;
  }

  if (carousel && legends.length) {
    carousel.innerHTML = legends.map(cardTemplate).join('');
    cards = $$('.legend-card', carousel);

    if (dotsEl) {
      dotsEl.innerHTML = legends.map((l, i) =>
        `<button class="dot-btn" type="button" data-goto="${i}" aria-label="Ver ${l.name}"${i === 0 ? ' aria-current="true"' : ''}></button>`
      ).join('');
    }
    index = 0;
    layoutCarousel();
  }

  function layoutCarousel() {
    if (!cards.length) return;

    cardWidth = cards[0].offsetWidth || cardWidth;
    const narrow = window.innerWidth < 640;
    const spread = narrow
      ? Math.min(cardWidth * 1.02, 300)
      : Math.min(cardWidth * 0.78, 300);

    cards.forEach((card, i) => {
      let offset = i - index;
      const n = cards.length;
      if (offset > n / 2) offset -= n;
      if (offset < -n / 2) offset += n;

      const abs = Math.abs(offset);
      const x = offset * spread;
      const z = abs === 0 ? 90 : 40 - abs * 140;
      const ry = Math.max(-44, Math.min(44, -offset * 25));
      const scale = abs === 0 ? 1 : Math.max(0.6, 0.9 - (abs - 1) * 0.12);
      const opacity = abs > 2 ? 0 : [1, 0.7, 0.36][abs];
      const blur = abs === 0 ? 0 : abs === 1 ? 0.7 : 2.2;

      card.style.transform = `translate(calc(-50% + ${x}px), -50%) translateZ(${z}px) rotateY(${ry}deg) scale(${scale})`;
      card.style.opacity = String(opacity);
      card.style.zIndex = String(40 - abs);
      card.style.pointerEvents = abs > 2 ? 'none' : '';
      card.style.filter = blur ? `blur(${blur}px) brightness(.78)` : '';
      card.classList.toggle('is-active', abs === 0);
      card.setAttribute('aria-hidden', abs === 0 ? 'false' : 'true');

      const btn = $('.card__btn', card);
      if (btn) btn.tabIndex = abs === 0 ? 0 : -1;
    });

    if (counterEl) {
      counterEl.innerHTML = `${pad(index + 1)} <i>/</i> ${pad(cards.length)}`;
    }
    if (dotsEl) {
      $$('.dot-btn', dotsEl).forEach((dot, i) => {
        const active = i === index;
        dot.classList.toggle('is-active', active);
        if (active) dot.setAttribute('aria-current', 'true');
        else dot.removeAttribute('aria-current');
      });
    }
  }

  function goTo(i) {
    if (!cards.length) return;
    const keepFocus = Boolean(carousel && carousel.contains(document.activeElement));
    index = ((i % cards.length) + cards.length) % cards.length;
    resetTilt();
    layoutCarousel();
    if (keepFocus && cards[index]) {
      const activeBtn = $('.card__btn', cards[index]);
      if (activeBtn) activeBtn.focus({ preventScroll: true });
    }
  }

  function startAutoplay() {
    if (autoplayId || reduced || !cards.length) return;
    autoplayId = window.setInterval(() => {
      if (autoPaused || modalOpen || document.hidden) return;
      index = (index + 1) % cards.length;
      resetTilt();
      layoutCarousel();
    }, 7000);
  }

  function resetTilt() {
    if (!cards[index]) return;
    const inner = $('.card__inner', cards[index]);
    const shine = $('.card__shine', cards[index]);
    if (inner) {
      inner.style.transform = '';
      inner.style.setProperty('--sx', '0px');
      inner.style.setProperty('--sy', '0px');
    }
    if (shine) {
      shine.style.setProperty('--px', '50%');
      shine.style.setProperty('--py', '0%');
    }
  }

  if (stage && cards.length) {
    stage.addEventListener('pointerenter', () => { autoPaused = true; });
    stage.addEventListener('pointerleave', () => {
      autoPaused = false;
      resetTilt();
    });
    stage.addEventListener('focusin', () => { autoPaused = true; });
    stage.addEventListener('focusout', () => {
      if (!stage.contains(document.activeElement)) autoPaused = false;
    });

    stage.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (e.target.closest('button, a, .modal')) return;
      dragStart = { x: e.clientX, y: e.clientY };
      didDrag = false;
      stage.classList.add('is-dragging');
      try { stage.setPointerCapture(e.pointerId); } catch (_) { /* ignorar */ }
    });

    stage.addEventListener('pointermove', (e) => {
      if (!dragStart) {
        tiltCard(e);
        return;
      }
      if (Math.abs(e.clientX - dragStart.x) > 10) didDrag = true;
    });

    stage.addEventListener('pointerup', (e) => {
      if (!dragStart) return;
      const dx = e.clientX - dragStart.x;
      dragStart = null;
      stage.classList.remove('is-dragging');
      if (didDrag && Math.abs(dx) > 45) {
        goTo(index + (dx < 0 ? 1 : -1));
      }
      if (didDrag) {
        clearTimeout(dragResetTimer);
        dragResetTimer = setTimeout(() => { didDrag = false; }, 280);
      }
    });

    stage.addEventListener('pointercancel', () => {
      dragStart = null;
      didDrag = false;
      stage.classList.remove('is-dragging');
    });
  }

  function tiltCard(e) {
    if (reduced || !cards[index]) return;
    const inner = $('.card__inner', cards[index]);
    if (!inner) return;
    const r = inner.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    if (px < 0 || px > 1 || py < 0 || py > 1) {
      inner.style.transform = '';
      return;
    }
    inner.style.transform = `rotateY(${((px - 0.5) * 9).toFixed(2)}deg) rotateX(${((0.5 - py) * 7).toFixed(2)}deg) translateZ(14px)`;
    inner.style.setProperty('--sx', ((0.5 - px) * 18).toFixed(1) + 'px');
    inner.style.setProperty('--sy', ((0.5 - py) * 18).toFixed(1) + 'px');
    const shine = $('.card__shine', cards[index]);
    if (shine) {
      shine.style.setProperty('--px', (px * 100).toFixed(1) + '%');
      shine.style.setProperty('--py', (py * 100).toFixed(1) + '%');
    }
  }

  if (carousel) {
    carousel.addEventListener('click', (e) => {
      const card = e.target.closest('.legend-card');
      if (!card) return;
      if (didDrag) return;
      const i = Number(card.dataset.index);
      if (i === index) openModal(i);
      else goTo(i);
    });
  }

  if (dotsEl) {
    dotsEl.addEventListener('click', (e) => {
      const dot = e.target.closest('[data-goto]');
      if (dot) goTo(Number(dot.dataset.goto));
    });
  }

  prevBtn?.addEventListener('click', () => goTo(index - 1));
  nextBtn?.addEventListener('click', () => goTo(index + 1));

  const legendsSection = $('#leyendas');
  if (legendsSection && 'IntersectionObserver' in window) {
    new IntersectionObserver((entries) => {
      carouselVisible = entries[0].isIntersecting;
    }, { threshold: 0.25 }).observe(legendsSection);
  }

  document.addEventListener('keydown', (e) => {
    if (modalOpen || !carouselVisible || !cards.length) return;
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    if (e.target.closest('input, textarea, select, [contenteditable]')) return;
    e.preventDefault();
    goTo(index + (e.key === 'ArrowRight' ? 1 : -1));
  });

  /* ------------------------------------------------------------------ MODAL */

  const modal = $('#modal');
  const modalPanel = $('.modal__panel');
  const modalScroll = $('#modalScroll');
  const modalClose = $('#modalClose');
  const modalArt = $('#modalArt');
  const modalType = $('#modalType');
  const modalTitle = $('#modalTitle');
  const modalRegion = $('#modalRegion');
  const modalFacts = $('#modalFacts');
  const modalStory = $('#modalStory');
  const modalSignals = $('#modalSignals');
  const modalCuriosities = $('#modalCuriosities');
  const modalVariants = $('#modalVariants');
  const modalAdvice = $('#modalAdvice');
  const modalCount = $('#modalCount');
  const modalPrev = $('#modalPrev');
  const modalNext = $('#modalNext');
  let modalIndex = 0;
  let lastFocused = null;

  function setScrollLock(lock) {
    if (lock) {
      const gap = window.innerWidth - document.documentElement.clientWidth;
      document.body.style.paddingRight = gap > 0 ? `${gap}px` : '';
      document.body.classList.add('modal-open');
    } else {
      document.body.classList.remove('modal-open');
      document.body.style.paddingRight = '';
    }
  }

  function openModal(i) {
    if (!modal || !legends[i]) return;
    const alreadyOpen = modalOpen;
    modalIndex = i;
    const l = legends[i];

    if (modalPanel) {
      modalPanel.style.setProperty('--a1-rgb', l.a1rgb);
      modalPanel.style.setProperty('--a2-rgb', l.a2rgb);
    }
    if (modalArt && l.art) {
      modalArt.src = l.art;
      modalArt.alt = `Ilustración 3D de ${l.name}`;
    }
    if (modalType) modalType.textContent = l.type;
    if (modalTitle) modalTitle.textContent = l.name;
    if (modalRegion) modalRegion.textContent = l.region;
    if (modalFacts) {
      modalFacts.innerHTML = [
        ['Dónde se cuenta', l.place],
        ['Cuándo aparece', l.hour],
        ['Cómo se reconoce', l.look],
        ['Origen del relato', l.origin]
      ].map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('');
    }
    if (modalStory) modalStory.innerHTML = l.story.map((p) => `<p>${p}</p>`).join('');
    if (modalSignals) modalSignals.innerHTML = l.signals.map((s) => `<li>${s}</li>`).join('');
    if (modalCuriosities) {
      modalCuriosities.innerHTML = (l.facts || []).map((f) => `<li>${f}</li>`).join('');
    }
    if (modalVariants) modalVariants.textContent = l.variants || '';
    if (modalAdvice) modalAdvice.textContent = l.advice;
    if (modalCount) modalCount.textContent = `${pad(i + 1)} / ${pad(legends.length)}`;
    if (modalScroll) modalScroll.scrollTop = 0;

    if (!alreadyOpen) {
      lastFocused = document.activeElement;
      setScrollLock(true);
      modalOpen = true;
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      modalClose?.focus({ preventScroll: true });
    }

    if (cards.length) {
      index = i;
      resetTilt();
      layoutCarousel();
    }
  }

  function closeModal() {
    if (!modal || !modalOpen) return;
    modalOpen = false;
    setScrollLock(false);
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    if (lastFocused && typeof lastFocused.focus === 'function') {
      lastFocused.focus({ preventScroll: true });
    }
  }

  modalClose?.addEventListener('click', closeModal);
  modal?.addEventListener('click', (e) => {
    if (e.target.closest('[data-close]')) closeModal();
  });
  modalPrev?.addEventListener('click', () => openModal((modalIndex - 1 + legends.length) % legends.length));
  modalNext?.addEventListener('click', () => openModal((modalIndex + 1) % legends.length));

  document.addEventListener('keydown', (e) => {
    if (!modalOpen) return;
    if (e.key === 'Escape') {
      closeModal();
      return;
    }
    if (e.key !== 'Tab') return;
    const focusables = $$('button, [href], [tabindex]:not([tabindex="-1"])', modal)
      .filter((el) => !el.disabled && el.offsetParent !== null);
    if (!focusables.length) return;
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  });

  /* --------------------------------------------------------------- SONIDO */

  const Sound = (() => {
    const AudioCtor = window.AudioContext || window.webkitAudioContext;
    let ctx = null;
    let master = null;
    let playing = false;
    let chirpTimer = null;
    let cryTimer = null;

    function setup() {
      ctx = new AudioCtor();
      master = ctx.createGain();
      master.gain.value = 0;
      master.connect(ctx.destination);

      /* Drone grave del monte */
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 520;
      filter.Q.value = 0.7;
      const droneGain = ctx.createGain();
      droneGain.gain.value = 0.16;
      filter.connect(droneGain);
      droneGain.connect(master);

      [55, 82.5, 110.3].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        osc.type = i === 2 ? 'triangle' : 'sine';
        osc.frequency.value = freq;
        const gain = ctx.createGain();
        gain.gain.value = [0.6, 0.3, 0.12][i];
        osc.connect(gain);
        gain.connect(filter);
        osc.start();
      });

      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.06;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 0.05;
      lfo.connect(lfoGain);
      lfoGain.connect(droneGain.gain);
      lfo.start();

      /* Viento / hojas */
      const buffer = ctx.createBuffer(1, ctx.sampleRate * 3, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let lastNoise = 0;
      for (let i = 0; i < data.length; i += 1) {
        const white = Math.random() * 2 - 1;
        lastNoise = (lastNoise + 0.02 * white) / 1.02;
        data[i] = lastNoise * 3.2;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      noise.loop = true;
      const band = ctx.createBiquadFilter();
      band.type = 'bandpass';
      band.frequency.value = 720;
      band.Q.value = 0.55;
      const noiseGain = ctx.createGain();
      noiseGain.gain.value = 0.06;
      noise.connect(band);
      band.connect(noiseGain);
      noiseGain.connect(master);
      noise.start();

      scheduleChirp();
      scheduleCry();
    }

    function chirp() {
      if (!playing || !ctx) return;
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = 3600 + Math.random() * 1400;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, t);
      for (let p = 0; p < 3; p += 1) {
        const start = t + p * 0.05;
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(0.02, start + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0005, start + 0.036);
      }
      osc.connect(gain);
      gain.connect(master);
      osc.start(t);
      osc.stop(t + 0.24);
    }

    function scheduleChirp() {
      clearTimeout(chirpTimer);
      chirpTimer = setTimeout(() => {
        chirp();
        scheduleChirp();
      }, 800 + Math.random() * 2400);
    }

    function cry() {
      if (!playing || !ctx) return;
      const t = ctx.currentTime;
      [0, 0.55].forEach((offset) => {
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        const start = t + offset;
        osc.frequency.setValueAtTime(760, start);
        osc.frequency.exponentialRampToValueAtTime(420, start + 0.34);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(0.042, start + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.46);
        osc.connect(gain);
        gain.connect(master);
        osc.start(start);
        osc.stop(start + 0.5);
      });
    }

    function scheduleCry() {
      clearTimeout(cryTimer);
      cryTimer = setTimeout(() => {
        cry();
        scheduleCry();
      }, 12000 + Math.random() * 9000);
    }

    async function toggle() {
      if (!AudioCtor) return false;
      if (!ctx) setup();
      if (ctx.state === 'suspended') await ctx.resume();
      playing = !playing;
      const now = ctx.currentTime;
      master.gain.cancelScheduledValues(now);
      master.gain.setValueAtTime(master.gain.value, now);
      master.gain.linearRampToValueAtTime(playing ? 0.9 : 0, now + (playing ? 1.2 : 0.6));
      if (!playing) {
        setTimeout(() => {
          if (!playing && ctx && ctx.state === 'running') ctx.suspend();
        }, 1000);
      }
      return playing;
    }

    return {
      toggle,
      get supported() { return Boolean(AudioCtor); }
    };
  })();

  const soundButtons = [$('#soundToggle'), $('#heroSound')].filter(Boolean);
  const heroSoundLabel = $('#heroSoundLabel');

  function paintSound(on) {
    soundButtons.forEach((btn) => {
      btn.classList.toggle('is-on', on);
      btn.setAttribute('aria-pressed', String(on));
    });
    const navSound = $('#soundToggle');
    if (navSound) {
      navSound.setAttribute('aria-label', on ? 'Silenciar sonido del monte' : 'Activar sonido del monte');
    }
    if (heroSoundLabel) {
      heroSoundLabel.textContent = on ? 'Silenciar el monte' : 'Escuchar el monte';
    }
  }

  if (!Sound.supported) {
    soundButtons.forEach((btn) => {
      btn.disabled = true;
      btn.setAttribute('aria-label', 'Tu navegador no permite audio');
    });
    if (heroSoundLabel) heroSoundLabel.textContent = 'Audio no disponible';
  } else {
    soundButtons.forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          paintSound(await Sound.toggle());
        } catch (_) {
          paintSound(false);
        }
      });
    });
  }

  /* ------------------------------------------------------------- NAV / SCROLL */

  const nav = $('#nav');
  const burger = $('#burger');
  const navLinks = $('#navLinks');
  const progressBar = $('#scrollProgress');
  const toTop = $('#toTop');

  burger?.addEventListener('click', () => {
    const open = nav.classList.toggle('nav--open');
    burger.setAttribute('aria-expanded', String(open));
  });

  navLinks?.addEventListener('click', (e) => {
    if (e.target.closest('a')) {
      nav.classList.remove('nav--open');
      burger?.setAttribute('aria-expanded', 'false');
    }
  });

  document.addEventListener('click', (e) => {
    if (!nav || !nav.classList.contains('nav--open')) return;
    if (!nav.contains(e.target)) {
      nav.classList.remove('nav--open');
      burger?.setAttribute('aria-expanded', 'false');
    }
  });

  let scrollTicking = false;

  function onScroll() {
    if (scrollTicking) return;
    scrollTicking = true;
    requestAnimationFrame(() => {
      const y = window.scrollY;
      nav?.classList.toggle('is-stuck', y > 40);

      if (progressBar) {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        progressBar.style.transform = `scaleX(${max > 0 ? Math.min(y / max, 1) : 0})`;
      }
      toTop?.classList.toggle('is-visible', y > 760);

      if (!reduced && heroContent && y < window.innerHeight) {
        heroContent.style.transform = `translateY(${y * 0.2}px)`;
        heroContent.style.opacity = String(Math.max(0, 1 - y / (window.innerHeight * 0.9)));
      }
      scrollTicking = false;
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  toTop?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: reduced ? 'auto' : 'smooth' });
  });

  /* Enlace activo según la sección visible */
  const navLinkEls = $$('.nav__links a');
  const sections = $$('main section[id]');
  if (sections.length && 'IntersectionObserver' in window) {
    const navObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        navLinkEls.forEach((a) => {
          a.classList.toggle('is-active', a.getAttribute('href') === `#${entry.target.id}`);
        });
      });
    }, { rootMargin: '-42% 0px -52% 0px' });
    sections.forEach((s) => navObserver.observe(s));
  }

  /* --------------------------------------------------------------- REVELADO */

  const revealEls = $$('[data-reveal]');
  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-in');
        obs.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -50px 0px' });
    revealEls.forEach((el) => revealObserver.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add('is-in'));
  }

  /* --------------------------------------------------------------- SUSURROS */

  const whisperText = $('#whisperText');
  const whisperSource = $('#whisperSource');
  const whisperSection = $('#susurros');
  const whispers = [
    { text: 'El monte no está vacío: está lleno de ojos que te miran.', source: '— dicho de los abuelos cruceños' },
    { text: 'Si el guajojó canta cerca de tu casa, guarda silencio y reza bajito.', source: '— tradición oral de la Chiquitanía' },
    { text: 'Al monte se entra pidiendo permiso, y se sale sin mirar atrás.', source: '— consejo de cazadores antiguos' },
    { text: 'La noche no es mala: es memoria. Solo hay que saber caminarla.', source: '— leyenda viva' }
  ];
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  let whisperToken = 0;
  let whisperRunning = false;

  async function whisperLoop() {
    const token = ++whisperToken;
    let i = 0;
    while (true) {
      if (token !== whisperToken) return;
      const w = whispers[i % whispers.length];
      if (whisperSource) whisperSource.textContent = w.source;

      if (reduced) {
        if (whisperText) whisperText.textContent = w.text;
        return;
      }

      if (whisperText) whisperText.textContent = '';
      for (let c = 1; c <= w.text.length; c += 1) {
        if (token !== whisperToken) return;
        if (whisperText) whisperText.textContent = w.text.slice(0, c);
        await sleep(26 + Math.random() * 32);
      }

      await sleep(3800);
      if (token !== whisperToken) return;

      for (let c = w.text.length; c >= 0; c -= 1) {
        if (token !== whisperToken) return;
        if (whisperText) whisperText.textContent = w.text.slice(0, c);
        await sleep(10);
      }
      await sleep(450);
      i += 1;
    }
  }

  if (whisperText && whisperSection) {
    if (reduced) {
      whisperText.textContent = whispers[0].text;
      if (whisperSource) whisperSource.textContent = whispers[0].source;
    } else if ('IntersectionObserver' in window) {
      const whisperObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
          if (!whisperRunning) {
            whisperRunning = true;
            whisperLoop();
          }
        } else if (whisperRunning) {
          whisperRunning = false;
          whisperToken += 1;
        }
      }, { threshold: 0.3 });
      whisperObserver.observe(whisperSection);
    } else {
      whisperLoop();
    }
  }

  /* ----------------------------------------------------------------- CANVAS */

  const skyCanvas = $('#sky');
  const hero = $('#inicio');
  const heroPortal = $('.hero__portal');

  if (skyCanvas && hero) {
    const ctx = skyCanvas.getContext('2d');
    const TAU = Math.PI * 2;
    const colors = [
      [255, 95, 143],
      [255, 77, 109],
      [255, 214, 224],
      [224, 70, 111]
    ];
    const sprites = colors.map(([r, g, b]) => {
      const c = document.createElement('canvas');
      c.width = 64;
      c.height = 64;
      const cg = c.getContext('2d');
      const grad = cg.createRadialGradient(32, 32, 0, 32, 32, 32);
      grad.addColorStop(0, 'rgba(255,255,255,.95)');
      grad.addColorStop(0.22, `rgba(${r},${g},${b},.9)`);
      grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
      cg.fillStyle = grad;
      cg.fillRect(0, 0, 64, 64);
      return c;
    });

    let W = 1;
    let H = 1;
    let raf = 0;
    let last = performance.now();
    const mouse = { x: 0, y: 0, tx: 0, ty: 0 };
    let fireflies = [];
    let stars = [];

    function seed() {
      const starCount = Math.round(Math.min(150, 60 + W / 12));
      const flyCount = Math.round(Math.min(42, 20 + W / 48));
      stars = Array.from({ length: starCount }, () => ({
        x: Math.random(),
        y: Math.random(),
        r: 0.5 + Math.random() * 1.5,
        ph: Math.random() * TAU,
        tw: 0.4 + Math.random() * 1.2,
        d: 0.2 + Math.random() * 0.8
      }));
      fireflies = Array.from({ length: flyCount }, () => {
        const z = 0.25 + Math.random() * 0.75;
        return {
          x: Math.random(),
          y: Math.random(),
          z,
          vx: (Math.random() - 0.5) * 0.028,
          vy: (Math.random() - 0.5) * 0.022,
          ph: Math.random() * TAU,
          tw: 0.5 + Math.random() * 1.4,
          sp: Math.floor(Math.random() * sprites.length)
        };
      });
    }

    function resizeSky() {
      const rect = hero.getBoundingClientRect();
      W = Math.max(1, rect.width);
      H = Math.max(1, rect.height);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      skyCanvas.width = Math.round(W * dpr);
      skyCanvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seed();
    }

    function draw(now, dt) {
      ctx.clearRect(0, 0, W, H);

      for (const s of stars) {
        const alpha = 0.16 + 0.5 * (0.5 + 0.5 * Math.sin(now * 0.0008 * s.tw + s.ph));
        ctx.globalAlpha = alpha;
        ctx.fillStyle = '#fff0f4';
        ctx.beginPath();
        ctx.arc(s.x * W + mouse.x * 14 * s.d, s.y * H + mouse.y * 10 * s.d, s.r, 0, TAU);
        ctx.fill();
      }

      ctx.globalCompositeOperation = 'lighter';
      for (const f of fireflies) {
        if (!reduced) {
          f.x += f.vx * dt;
          f.y += f.vy * dt;
          if (f.x < -0.08) f.x = 1.08;
          if (f.x > 1.08) f.x = -0.08;
          if (f.y < -0.08) f.y = 1.08;
          if (f.y > 1.08) f.y = -0.08;
        }
        const twinkle = 0.5 + 0.5 * Math.sin(now * 0.0011 * f.tw + f.ph);
        const size = (10 + 28 * f.z) * (0.8 + twinkle * 0.4);
        const px = f.x * W + mouse.x * 36 * f.z;
        const py = f.y * H + mouse.y * 26 * f.z;
        ctx.globalAlpha = 0.25 + 0.6 * twinkle;
        ctx.drawImage(sprites[f.sp], px - size / 2, py - size / 2, size, size);
      }
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
    }

    function loop(now) {
      if (document.hidden) {
        raf = 0;
        return;
      }
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      mouse.x += (mouse.tx - mouse.x) * 0.06;
      mouse.y += (mouse.ty - mouse.y) * 0.06;
      draw(now, dt);
      raf = requestAnimationFrame(loop);
    }

    function startSky() {
      if (reduced || raf) return;
      last = performance.now();
      raf = requestAnimationFrame(loop);
    }

    resizeSky();
    if (reduced) draw(performance.now(), 0);
    else startSky();

    let resizeTimer = null;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        resizeSky();
        if (reduced) draw(performance.now(), 0);
        layoutCarousel();
      }, 150);
    });

    hero.addEventListener('pointermove', (e) => {
      const r = hero.getBoundingClientRect();
      const nx = (e.clientX - r.left) / r.width - 0.5;
      const ny = (e.clientY - r.top) / r.height - 0.5;
      mouse.tx = nx;
      mouse.ty = ny;
      if (heroPortal && !reduced) {
        heroPortal.style.transform = `translate(calc(-50% + ${(nx * 18).toFixed(1)}px), calc(-50% + ${(ny * 14).toFixed(1)}px))`;
      }
    }, { passive: true });

    hero.addEventListener('pointerleave', () => {
      mouse.tx = 0;
      mouse.ty = 0;
      if (heroPortal) heroPortal.style.transform = '';
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (raf) cancelAnimationFrame(raf);
        raf = 0;
      } else {
        startSky();
      }
    });
  }

  /* ------------------------------------------------------------- RESPLANDOR */

  const glow = $('#cursorGlow');

  if (glow && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
    let tx = window.innerWidth / 2;
    let ty = window.innerHeight / 2;
    let gx = tx;
    let gy = ty;

    window.addEventListener('pointermove', (e) => {
      tx = e.clientX;
      ty = e.clientY;
    }, { passive: true });

    (function glowLoop() {
      gx += (tx - gx) * 0.12;
      gy += (ty - gy) * 0.12;
      glow.style.transform = `translate3d(${gx.toFixed(1)}px, ${gy.toFixed(1)}px, 0) translate(-50%, -50%)`;
      requestAnimationFrame(glowLoop);
    })();
  }

  /* ---------------------------------------------------------------- MARQUEE */

  const marqueeTrack = $('#marqueeTrack');
  if (marqueeTrack && legends.length) {
    const items = legends.map((l) => `<span>${l.name}</span>`).join('');
    marqueeTrack.innerHTML = items.repeat(3) + items.repeat(3);
  }

  /* ---------------------------------------------------------------- JICHI */

  const JICHI_SVG = `
    <svg viewBox="0 0 100 100" aria-hidden="true">
      <ellipse cx="50" cy="30" rx="27" ry="6"/>
      <path d="M34 29c1-8 2-14 6-18 6-5 14-5 20 0 4 4 5 10 6 18"/>
      <circle cx="50" cy="44" r="10"/>
      <path d="M42 54c-2 8-4 15-4 22 0 4 24 4 24 0 0-7-2-14-4-22"/>
      <path d="M44 76l-3 12M56 76l3 12"/>
      <path d="M40 78l-7 3M60 78l7 3"/>
      <path d="M38 60l-9 6M62 60l9 6"/>
      <circle cx="46.5" cy="43" r="1.7" fill="currentColor" stroke="none"/>
      <circle cx="53.5" cy="43" r="1.7" fill="currentColor" stroke="none"/>
    </svg>`;

  function spawnJichi() {
    $$('.jichi-runner').forEach((n) => n.remove());
    const el = document.createElement('div');
    el.className = 'jichi-runner';
    el.innerHTML = JICHI_SVG;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 6200);
  }

  document.addEventListener('keydown', (e) => {
    if (modalOpen || e.repeat) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key.toLowerCase() !== 'j') return;
    if (e.target.closest('input, textarea, select, [contenteditable]')) return;
    spawnJichi();
  });

  /* ------------------------------------------------------------------ AÑO */

  const yearEl = $('#year');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* Recalcular cuando las fuentes terminen de cargar */
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => layoutCarousel());
  }
})();
