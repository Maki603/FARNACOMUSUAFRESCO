/* =========================================================
   Leyendas de Santa Cruz — datos, arte 3D e información
   Cada leyenda trae su ilustración (assets/img), ficha,
   relato en tres párrafos, señales, datos y versiones.
   ========================================================= */

window.LEGENDS = [
  {
    id: 'guajoyo',
    name: 'El Guajojó',
    type: 'El canto misterioso del monte',
    region: 'Bosques y quebradas · Oriente boliviano',
    teaser: 'En la oscuridad del bosque, su canto recuerda una antigua historia de amor y despedida.',
    a1: '#4c9b68',
    a2: '#14532d',
    a1rgb: '76,155,104',
    a2rgb: '20,83,45',
    art: 'assets/img/guajajo.jpg',
    place: 'Bosques, chacos y quebradas del oriente boliviano',
    hour: 'Desde el anochecer hasta el amanecer',
    look: 'Ave pequeña y nocturna, de plumaje parduzco; canta como un llanto de mujer',
    origin: 'Tradición oral de la Chiquitanía y del norte cruceño; su nombre imita su canto',
    story: [
      'En los montes del oriente, cuando cae la noche, se escucha un canto que parece pronunciar su propio nombre: gua-jo-jó. Los mayores cuentan que, hace mucho tiempo, una joven esperaba cada tarde el regreso de alguien querido que se había internado en el bosque.',
      'Pasaron los días y la joven siguió llamándolo entre los árboles. Según la leyenda, su tristeza se convirtió en el canto de un ave nocturna, que desde entonces repite su llamado cuando el monte queda en silencio.',
      'Por eso, algunas familias relacionan el canto del guajojó con la nostalgia y las despedidas. La historia también recuerda que las aves del bosque forman parte de la vida y la memoria de las comunidades.'
    ],
    signals: ['Canto nocturno', 'Suena cerca de las casas', 'Nunca se imita', 'Anuncia una despedida'],
    facts: [
      'Su nombre es una onomatopeya: repite el sonido «gua-jo-jó» que se escucha en el monte.',
      'El guajojó existe de verdad y tiene hábitos nocturnos; su grito se parece a un lamento.',
      'En varias versiones el ave es el alma de una madre que perdió a su hijo en el monte.'
    ],
    variants: 'En la Chiquitanía se cuenta como una joven que llora a su amado; en otras zonas, como el lamento de una madre. Casi todas las versiones coinciden en que el canto avisa una despedida.',
    advice: 'Si escuchas el canto muy cerca, no lo imites ni lo grabes para burlarte. Los mayores bajan la voz, guardan silencio y rezan bajito. Es una forma de despedirse con respeto.'
  },
  {
    id: 'jichi',
    name: 'El Jichi',
    type: 'Protector de la naturaleza',
    region: 'Monte y chacos · Chiquitanía y Guarayos',
    teaser: 'Un pequeño guardián vigila los árboles y los animales; no le gusta que dañen el monte.',
    a1: '#4c9b68',
    a2: '#14532d',
    a1rgb: '76,155,104',
    a2rgb: '20,83,45',
    art: 'assets/img/jichi.jpg',
    place: 'Monte, chacos y caminos de la Chiquitanía, Guarayos y Ñuflo de Chávez',
    hour: 'Cuando cae la noche y el monte se queda solo',
    look: 'Hombrecito moreno, de sombrero enorme y pies al revés; risas que no se sabe de dónde vienen',
    origin: 'Creencia guaraní y chiquitana: el jichi cuida a los animales y a los árboles',
    story: [
      'En los relatos de la Chiquitanía y Guarayos se habla del jichi, un ser pequeño que conoce cada sendero y cada vertiente. Lo describen con un sombrero grande y huellas difíciles de seguir, porque sus pies apuntan hacia atrás.',
      'El jichi es considerado protector del monte y de los animales. Cuando alguien entra al bosque sin respeto o toma más de lo necesario, la leyenda dice que puede confundir sus caminos para enseñarle a cuidar lo que encuentra.',
      'Quienes respetan la naturaleza, en cambio, pueden recorrer el monte en paz. Así, el relato transmite una enseñanza sencilla: aprovechar los recursos con responsabilidad y proteger los lugares que dan vida a la comunidad.'
    ],
    signals: ['Huellas al revés', 'Risas entre los árboles', 'Silbidos que desorientan', 'Protege a los animales'],
    facts: [
      'Sus pies al revés son su truco favorito: las huellas parecen alejarse cuando en realidad se acerca.',
      'Se dice que vive en los troncos huecos y en las cuevas de los cerros del monte.',
      'Es el guardián de los animales: castiga al que mata de más y premia al que respeta.'
    ],
    variants: 'Algunos lo imaginan como un niño travieso y otros como un anciano diminuto. En el norte cruceño se lo llama también «dueño del monte» y se le deja una ofrenda de tabaco o chicha antes de cazar.',
    advice: 'Entra al monte pidiendo permiso, no silbes de noche y no mates más de lo que vas a comer. Si te pierdes, no corras: quédate quieto, respira y espera a que amanezca.'
  },
  {
    id: 'carreton',
    name: 'El Carretón',
    type: 'El misterio de las calles antiguas',
    region: 'Casco viejo y calles del pueblo',
    teaser: 'Cuando el pueblo queda en silencio, se escucha el paso de una carreta que parece no tener conductor.',
    a1: '#4c9b68',
    a2: '#14532d',
    a1rgb: '76,155,104',
    a2rgb: '20,83,45',
    art: 'assets/img/carreton.jpg',
    place: 'Calles del casco viejo y caminos de tierra de los pueblos',
    hour: 'Entre las doce y las tres de la madrugada',
    look: 'Carreta de bueyes sin conductor, con cadenas que suenan y un farol rojo que se apaga',
    origin: 'Relato de origen colonial, contado en todo el oriente boliviano',
    story: [
      'En algunos pueblos cruceños se cuenta que, cuando la noche está avanzada, se oye el crujido de unas ruedas antiguas y el sonido de cadenas sobre la calle. Los perros ladran y, por un momento, parece que una carreta atraviesa el pueblo.',
      'La tradición imagina al carretón avanzando sin conductor, envuelto en misterio. Hay versiones que lo relacionan con antiguas historias coloniales y con las promesas que las personas dejan sin cumplir.',
      'Los abuelos cuentan este relato para recordar que la palabra y los compromisos tienen valor. Aunque cada pueblo agrega detalles distintos, el sonido de la carreta sigue siendo parte de las historias nocturnas del oriente.'
    ],
    signals: ['Perros que aúllan', 'Chirrido de cadenas', 'Tres golpes en la puerta', 'Solo pasa de madrugada'],
    facts: [
      'El dato más repetido es el orden: primero los perros, después las cadenas, al final los tres golpes.',
      'En algunas versiones la carreta va vacía; en otras, lleva gente que no se mueve.',
      'Se dice que el farol del carretón se apaga justo cuando pasa frente a tu casa.'
    ],
    variants: 'En unos pueblos se la describe tirada por bueyes flacos; en otros, por caballos negros. Hay quien asegura que se puede escuchar el nombre de los pasajeros si uno se queda quieto y no mira.',
    advice: 'Si los perros aúllan sin motivo y escuchas cadenas, no abras. Apaga la luz, no mires por la ventana y no respondas a los tres golpes. La noche pasa, y con ella el carretón.'
  },
  {
    id: 'viudita',
    name: 'La Viudita',
    type: 'La mujer del camino',
    region: 'Caminos rurales · Cotoca y La Guardia',
    teaser: 'Una figura vestida de negro aparece en los caminos y desaparece sin dejar rastro.',
    a1: '#4c9b68',
    a2: '#14532d',
    a1rgb: '76,155,104',
    a2rgb: '20,83,45',
    art: 'assets/img/viudita.jpg',
    place: 'Caminos de tierra cerca de Cotoca, La Guardia y los pueblos del este',
    hour: 'Después de la medianoche, cuando ya no pasa nadie',
    look: 'Mujer de negro con velo rojo, olor a tierra mojada; desaparece en las curvas',
    origin: 'Versión cruceña de la viuda de los caminos, muy contada por transportistas',
    story: [
      'La Viudita aparece en los relatos de caminos rurales como una mujer vestida de negro que espera a un costado de la senda. Algunos viajeros dicen haberla visto bajo la luz tenue de la luna, siempre en lugares silenciosos y apartados.',
      'La historia cuenta que pide ayuda para llegar al pueblo, pero al acercarse a una curva o a un viejo cruce, desaparece sin explicación. Unos dicen que busca a una persona que nunca regresó; otros creen que es un recuerdo de tiempos pasados.',
      'La leyenda se transmite como una advertencia para ser prudentes al viajar de noche y no detenerse en lugares solitarios. También refleja el misterio que las comunidades asocian con los caminos antiguos.'
    ],
    signals: ['Velo negro', 'Huele a tierra mojada', 'Desaparece en una curva', 'Pide que la lleven'],
    facts: [
      'Los choferes suelen reconocerla por el olor a tierra mojada, incluso en noches secas.',
      'Se aparece siempre en el mismo tramo de camino, casi nunca en el centro del pueblo.',
      'En varias versiones lleva un velo rojo, como el de las viudas antiguas.'
    ],
    variants: 'Hay quien la describe joven y quien la describe mayor. En algunos relatos pide que la lleven al cementerio; en otros, a una casa que ya no existe.',
    advice: 'Si ves a una mujer de negro en un camino solitario y sientes que algo no está bien, no te detengas. Si ya la llevas, no la mires por el retrovisor y reza en silencio hasta llegar a tu casa.'
  },
  {
    id: 'bufeo',
    name: 'El Bufeo Colorado',
    type: 'El espíritu de los ríos',
    region: 'Ríos del norte cruceño · Ñuflo de Chávez',
    teaser: 'Un delfín rosado de los ríos amazónicos inspira una historia sobre misterio y encanto.',
    a1: '#4c9b68',
    a2: '#14532d',
    a1rgb: '76,155,104',
    a2rgb: '20,83,45',
    art: 'assets/img/bufeo.jpg',
    place: 'Ríos Grande, Piraí y afluentes del norte cruceño',
    hour: 'En fiestas y noches de luna de los pueblos ribereños',
    look: 'Joven alto de traje blanco y sombrero ancho; huele a río y baila demasiado bien',
    origin: 'Tradición de los pueblos ribereños y del norte amazónico boliviano',
    story: [
      'En los ríos de la región amazónica vive el bufeo colorado, conocido también como delfín rosado. Su presencia en el agua inspiró relatos que se cuentan en comunidades ribereñas y que mezclan la observación de la naturaleza con la imaginación popular.',
      'Según la leyenda, durante las fiestas puede aparecer un joven elegante, vestido de blanco y con sombrero. Baila con los invitados y, antes del amanecer, se marcha hacia el río, donde revela su verdadera relación con el bufeo.',
      'El relato recuerda el vínculo entre las personas y los ríos, y también invita a respetar sus aguas y animales. El bufeo es un animal real, y su figura ocupa un lugar especial en las historias de la Amazonía.'
    ],
    signals: ['Traje blanco y sombrero', 'Huele a río', 'Baila demasiado bien', 'Desaparece al amanecer'],
    facts: [
      'El bufeo colorado es un animal real: el delfín rosado de los ríos amazónicos.',
      'Su piel se vuelve más rosada con la edad y con el esfuerzo de nadar.',
      'En el norte se dice que, si el agua se agita sin viento, el bufeo anda cerca.'
    ],
    variants: 'En algunos pueblos el encantado se aparece como un joven rubio; en otros, como un músico que toca el violín en la orilla. Casi siempre la historia termina igual: la muchacha despierta sola, mojada y lejos de la fiesta.',
    advice: 'Si un desconocido elegante te invita a la orilla del río de noche, no vayas sola. Y si el sombrero no se lo quita ni para bailar, mejor vuelve a la fiesta con tus amigas.'
  },
  {
    id: 'llorona',
    name: 'La Llorona',
    type: 'El lamento junto al agua',
    region: 'Ríos y curichis · Todo el oriente',
    teaser: 'En las noches cercanas a los curichis se escucha un lamento que forma parte de la tradición oral.',
    a1: '#4c9b68',
    a2: '#14532d',
    a1rgb: '76,155,104',
    a2rgb: '20,83,45',
    art: 'assets/img/llorona.jpg',
    place: 'Curichis, quebradas y ríos de todo el oriente boliviano',
    hour: 'Noches sin luna, cerca del agua',
    look: 'Silueta blanca con el cabello sobre la cara; un llanto que se acerca cuando le hablas',
    origin: 'Historia extendida por toda América Latina, con versiones cruceñas',
    story: [
      'En los pueblos cercanos a ríos y curichis se cuenta que, cuando todo queda en calma, puede escucharse el llanto de una mujer a la distancia. La figura de la Llorona aparece en numerosas tradiciones de América Latina, con detalles que cambian de una región a otra.',
      'En algunas versiones del oriente boliviano, la mujer camina cerca del agua buscando a sus seres queridos. Su lamento se mezcla con el sonido de la noche y quienes conocen la historia aconsejan no acercarse a la orilla cuando está oscuro.',
      'Además del misterio, el relato transmite una recomendación de cuidado: disfrutar de los ríos durante el día, respetar sus corrientes y no acercarse al agua sin compañía.'
    ],
    signals: ['Llanto cerca del agua', 'Silueta blanca', 'Cabello sobre la cara', 'Se acerca si le hablas'],
    facts: [
      'La historia existe en casi toda América Latina, con nombres y detalles distintos en cada país.',
      'En el oriente boliviano se la asocia a los curichis y a los ríos que crecen en la noche.',
      'El detalle más repetido es que el llanto se escucha más cerca cuando uno le responde.'
    ],
    variants: 'En algunas versiones llora por sus hijos; en otras, por un amor perdido. Hay quien dice que solo asusta, y quien asegura que avisa de un peligro real en el agua.',
    advice: 'No le contestes, no la sigas y no te acerques a la orilla de noche. Si el llanto te sorprende, camina hacia donde hay gente y luz, y avisa a un adulto.'
  }
];
